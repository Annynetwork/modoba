This project has been deprecated in favor of automx2.
You can find automx2 on GitHub: https://github.com/rseichter/automx2
